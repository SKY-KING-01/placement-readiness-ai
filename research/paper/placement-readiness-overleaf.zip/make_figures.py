"""Rebuild manuscript figures from the committed synthetic study."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import joblib
import matplotlib
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, mean_absolute_error, precision_recall_curve

matplotlib.use("Agg")
from matplotlib import pyplot as plt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path, help="Path to the placement-readiness-ai checkout")
    args = parser.parse_args()
    project = args.project.resolve()
    sys.path.insert(0, str(project))
    from app.ml.features import FEATURES
    from ml.classification.models import classifiers
    from ml.features.build import build

    def fitted(task):
        directory = project / "ml/artifacts"
        model_path = directory / f"{task}.joblib"
        metadata = json.loads((directory / f"{task}.json").read_text())
        if hashlib.sha256(model_path.read_bytes()).hexdigest() != metadata["sha256"]:
            raise ValueError(f"{task} artifact digest mismatch")
        return joblib.load(model_path)

    saved = Path(__file__).resolve().parent / "figures"
    saved.mkdir(exist_ok=True)
    source = project / "data/synthetic/reassessments"
    features = build(source)
    scores = pd.read_csv(source / "assessments.csv")

    colors = ["#24577b", "#14766b", "#a44e34"]
    plt.rcParams.update({
        "font.family": "serif", "font.size": 8, "axes.labelsize": 8, "axes.spines.right": False,
        "axes.spines.top": False, "axes.linewidth": 0.6, "grid.alpha": 0.2, "pdf.fonttype": 42,
    })

    fig, ax = plt.subplots(figsize=(3.48, 1.9), layout="constrained")
    summary = scores.groupby("attempt").readiness
    days = (summary.mean().index.to_numpy() - 1) * 14
    ax.fill_between(days, summary.quantile(0.25), summary.quantile(0.75),
                    color=colors[0], alpha=0.15, label="Middle 50% of scores")
    ax.plot(days, summary.median(), 'o-', markersize=3, linewidth=1.45,
            color=colors[0], label="Median")
    ax.axhline(75, color=colors[2], linewidth=.8, linestyle="--", label="75-point threshold")
    ax.set(xlabel="Days from baseline", ylabel="Role-weighted readiness", xticks=days, ylim=(49, 89))
    ax.grid(axis="y")
    ax.legend(fontsize=6.9, loc="lower right", frameon=False)
    fig.savefig(saved / "readiness_history.pdf")
    plt.close(fig)

    known = features.loc[features.complete_followup & features.ready_within_60_days.notna()]
    train, test = (known.loc[known.split == split] for split in ("train", "test"))
    target = "ready_within_60_days"
    models = classifiers(42)
    all_results = pd.read_csv(project / "research/classification_results.csv").set_index("model")
    fig, ax = plt.subplots(figsize=(3.48, 2.08), layout="constrained")
    for (name, built), color, style in zip(models.items(), colors, ("-.", "-", ":"), strict=True):
        model = fitted("classification") if name == "Random Forest" else built.fit(
            train[list(FEATURES)], train[target].astype(int)
        )
        probability = model.predict_proba(test[list(FEATURES)])[:, 1]
        precision, recall, _ = precision_recall_curve(test[target], probability)
        ap = average_precision_score(test[target], probability)
        assert abs(ap - all_results.loc[name, "pr_auc"]) < 0.000001
        short = "Logistic reg." if name == "Logistic Regression" else name
        ax.step(recall, precision, where="post", color=color, linewidth=1.35,
                linestyle=style, label=f"{short} (AP {ap:.3f})")
    ax.axhline(test[target].mean(), color="#777777", linewidth=.8,
               linestyle="--", label="Positive prevalence (0.467)")
    ax.set(xlabel="Recall", ylabel="Precision", xlim=(0, 1.02), ylim=(0.0, 1.025))
    ax.grid(axis="y")
    ax.legend(fontsize=6.6, loc="lower left", frameon=False)
    fig.savefig(saved / "precision_recall.pdf")
    plt.close(fig)

    reg = features.loc[(features.split == "test") & features.next_score.notna()].copy()
    reg["predicted"] = np.clip(fitted("regression").predict(reg[list(FEATURES)]), 0, 100)
    assert abs(mean_absolute_error(reg.next_score, reg.predicted) - 2.333078) < .000001
    fig, ax = plt.subplots(figsize=(3.48, 2.10), layout="constrained")
    ax.plot([46, 92], [46, 92], color="#707070", linestyle="--", linewidth=.8, label="Perfect agreement")
    ax.scatter(reg.next_score, reg.predicted, s=14, color=colors[0], alpha=.67, edgecolor="none",
               label="Held-out forecast")
    ax.set(xlabel="Observed next score", ylabel="Predicted next score", xlim=(46, 92), ylim=(46, 92),
           xticks=[50, 60, 70, 80, 90], yticks=[50, 60, 70, 80, 90])
    assert reg[["next_score", "predicted"]].ge(46).all().all() and reg[["next_score", "predicted"]].le(92).all().all()
    ax.grid()
    ax.legend(fontsize=6.8, loc="upper left", frameon=False)
    fig.savefig(saved / "next_score.pdf")
    plt.close(fig)

    gain = (abs(reg.current - reg.next_score) - abs(reg.predicted - reg.next_score)).groupby(reg.student_id).mean()
    resample = np.random.default_rng(42).choice(gain.to_numpy(), size=(10000, len(gain)), replace=True)
    quantiles = np.quantile(resample.mean(axis=1), [.025, .975])
    print("Student-cluster bootstrap: mean gain", round(float(gain.mean()), 4),
          "95% percentile interval", [round(float(x), 4) for x in quantiles])
    print("Follow-up summary by attempt")
    print(scores.groupby("attempt").readiness.agg(["min", "median", "max"]).round(2))
    print("Landmark eligibility")
    print(features.groupby(["assessment_count", "label_status"]).size().to_string())
    print("Observed labels", known.groupby("split")[target].agg(["size", "sum"]))


if __name__ == "__main__":
    main()
