# Role-Aware Placement Readiness

Upload this ZIP as a new Overleaf project. The main document is `main.tex`
and the compiler is pdfLaTeX. The archive includes the IEEEtran style,
references and the three vector figures.

For a local build, run `latexmk -pdf main.tex`.

The optional figure script uses the private project checkout and its Python
environment. Run `python make_figures.py /path/to/placement-readiness-ai`
to regenerate figures and print the paired bootstrap calculation.
